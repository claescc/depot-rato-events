export default function EmptyState() {
  return (
    <div className="w-full flex justify-center bg-emptystate bg-center bg-no-repeat ">
      <div className="h-screen"></div>
    </div>
  )
}
