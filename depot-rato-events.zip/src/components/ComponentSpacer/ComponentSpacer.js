const ComponentSpacer = () => {
  return <div className="dre-spacer"></div>
}

export default ComponentSpacer
