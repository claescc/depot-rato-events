// import { useTranslation } from "react-i18next"

const SponsorFilterList = () => {
  //const { t } = useTranslation()

  return (
    <div className="dre-container">
      <div> SponsorFilterList</div>
    </div>
  )
}

export default SponsorFilterList
