const mailConfig = {
  serviceid: process.env.REACT_APP_DRE_MAIL_SERVICE_ID,
  templateid: process.env.REACT_APP_DRE_MAIL_TEMPLATE_ID,
  publickey: process.env.REACT_APP_DRE_MAIL_PUBLIC_KEY,
}

export const mail = mailConfig
